
/*
CLASE DBCONTEXT:

DbContext Clase:

Definicion:

Una instancia de DbContext representa una combinación de los patrones de unidad de trabajo y 
repositorio, de modo que se puede usar para consultar desde una base de datos y agrupar los 
cambios que, a continuación, se escribirán en el almacén como una unidad. DbContext es 
conceptualmente similar a ObjectContext.

-----------------------------------------------------------------------------------------------
public class DbContext : IDisposable, 
System.Data.Entity.Infrastructure.IObjectContextAdapter
---------------------------------------------------------------------------------------------

Herencia
    Object
    DbContext

Derivado
    System.Data.Entity.Infrastructure.TransactionContext
    System.Data.Entity.Migrations.History.HistoryContext

Implementaciones
    IObjectContextAdapter IDisposable

-----------------------------------------------------------------------------------------------

Comentarios:

DbContext se usa normalmente con un tipo derivado que contiene DbSet<TEntity> propiedades para 
las entidades raíz del modelo. Estos conjuntos se inicializan automáticamente cuando se crea la 
instancia de la clase derivada. 
______________
CONSTRUCTORES:
--------------
* DbContext()

* DbContext(DbCompiledModel)

* DbContext(DbConnection, Boolean)

* DbContext(DbConnection, DbCompiledModel, Boolean)

* DbContext(ObjectContext, Boolean)

* DbContext(String)

* DbContext(String, DbCompiledModel)

________
METODOS:
--------
* Dispose()

* Entry(Object)

* Entry<TEntity>(TEntity)

* Equals(Object)

* GetHashCode()

* GetType()

* GetValidationErrors()

* OnModelCreating(DbModelBuilder)

* SaveChanges()

* SaveChangesAsync()

* SaveChangesAsync(CancellationToken)

* Set(Type)

* Set<TEntity>()

* ShouldValidateEntity(DbEntityEntry)

* ToString()

* ValidateEntity(DbEntityEntry, IDictionary<Object,Object>)


INFORMACION COMPLETA:

https://learn.microsoft.com/es-es/dotnet/api/system.data.entity.dbcontext?view=entity-framework-6.2.0    

*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUD2023.Shared;

using Swashbuckle.AspNetCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Server.Models;


namespace Server.Models {
    public class UserContext : DbContext {


         protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Filename=Productos.db");
    }

    
        public UserContext() { } 
        public UserContext(DbContextOptions<UserContext> options) : base (options) { }
   /*
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=DBName;Integrated Security=True");
        }
*/



        public DbSet<User> Users { get; set; } = null!;
    }

    


    
}

/*

//ESTAS LINEAS DE CODIGO PERTENECEN A LA DESCRIPCION DEL VIDEO:


namespace Server.Models
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base(options) { }

public DbSet<User>? Users { get;set; } 

public DbSet<User>? _userContext { get;set; }

    
 
    }
}
*/



  /*  

--------------------  
--------------------
  NOTA IMPORTANTE    ==== > DADO QUE LA FUNCIONALIDAD PARA HACER MIGRACIONES DEPENDE MUCHO
--------------------
--------------------
DE QUE LA CLASE "DbContext" ESTE MUY BIEN CONFIGURADA (SEGUN EL ENTORNO DE TRABAJO)
SE MODIFICO DIFERENTE Al CODE DEL VIDEOTUTORIAL PARA QUE PUDIESE SER CREADA..


PARA REALIZAR LA MIGRACION (QUE CASI NO SE PUEDE REALIZAR
DEBIDO A ERRORES DE COMPILACION O RECONOCIMIENTO DB EN COMPILADOR
SE RECURRIO A CONSULTAR COMO SE PODIA CORREGIR EL ERROR
FUENTE DE INFORMACION:

https://learn.microsoft.com/en-us/ef/core/cli/dbcontext-creation?tabs=vs



LAS MIGRACIONES DEPENDEN MUCHO DE LA CONFIGURACION EN EL DBCONTEXT




  */


