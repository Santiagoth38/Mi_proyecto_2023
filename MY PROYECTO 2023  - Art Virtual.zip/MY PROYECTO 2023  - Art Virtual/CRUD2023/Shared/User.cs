using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



//PRIMERO SE CREAN LOS OBJETOS CON MEMORIA QUE VAN A APARECER EN EL LADO DEL CLIENTE:


namespace CRUD2023.Shared //"de namespace Shared" se modifico a "namespace CRUD2023.Shared"
{
    public class User
    {
        
public int Id {get; set;}

 public string Producto {get; set;} =null!;  //Name

 public string Correo {get; set; } =null!;  //Email

 public string Codigo { get; set;} =null!;  //Password

     
}}